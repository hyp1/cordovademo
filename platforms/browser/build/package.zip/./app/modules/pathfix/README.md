pathfix
========

The pathfix module for DrupalGap. Download and enable the companion Drupal
module on your Drupal site for this DrupalGap module to work:

https://drupal.org/sandbox/signalpoint/2068317

